d={'brand':'benz','model':'c200','color':'black','year':2024,'brand':'BMW','model':'z4'}
#o=d.get('brand','not found')
#print(d['model'])
#o=type(d.values())
#o=type(d.keys())
#o=type(d.items())
#print(o)
'''for i,j in d.items():
    print(i,':',j)'''
d['cylander']=8
print(d)
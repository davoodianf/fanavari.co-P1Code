l=[]
while True:
    a=input('enter : ')
    
    if a=='exit':
        break
    l.append(a)
print(l)
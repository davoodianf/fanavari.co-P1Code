'''l=[]
for i in range(4):
    a=input('enter : ')
    if a.isdigit():
        a=int(a)
    l.append(a)
print(l)'''

lc=[]
ls=[]

for i in range(4):
    a=input('select class with c and score with s :')
    if a=='c':
        b=input('enter :')
        lc.append(b)
    elif a=='s':
        b=input('enter : ')
        ls.append(b)
    else:
        print('invalid')
        
print(' list of class : ',lc)
print('list of score : ',ls)
l=[100,20,30,8,6,9,80,30,150,120]
#l1=['z','p']
#print(l1+l1)
#print(l1*3)
#print(1000 not in l)
'''m=-1
for i in l:
    if i>m:
        m=i
print(m)
    
l.remove(30)
print(l)
for i in l:
    if i==30:
        l.remove(i)
print(l)

l.insert(3, 'reza')
print(l)'''



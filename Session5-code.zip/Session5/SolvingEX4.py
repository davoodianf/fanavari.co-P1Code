'''pa=input('enter your password : ')
lpa=len(pa)
#print(lpa)
if lpa==8:
    a=pa[:4]
    d=pa[4:]
    #print(a)
    #print(d)
    if a.isalpha() and d.isdigit():
        print('valid')
        
    else:
        print('not valid')

else:
    print('not valid')'''
    
    
pa=input('enter your password : ')
lpa=len(pa)
#print(lpa)
a=pa[:4]
d=pa[4:]
if lpa==8 and a.isalpha() and d.isdigit():
    print('valid')
        

else:
    print('not valid')
    
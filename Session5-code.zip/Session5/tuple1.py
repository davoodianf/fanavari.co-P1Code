t=('ali',5,6,4,4,3,2,4)
t1=('z','x')
#print(type(t))
#print('reza' in t)
#g=t.count('reza')
#print(tuple(reversed(t)))
#print(g)
'''
t1=(1,2)
t2=(2,1)
print(t1==t2)'''
#t[0]='reza'

#print(t+t1)
l=list(t)
l[0]='reza'
print(l)
print(tuple(l))
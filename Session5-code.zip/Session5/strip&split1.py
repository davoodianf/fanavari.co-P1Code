#s='this is python language'
#f=s.split()
s='###this is python language****'
f=s.lstrip('#')
r=f.rstrip('*')
print(r)
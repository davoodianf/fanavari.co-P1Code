'''l=[1,2,3,8,6,'ali']
l[5]='reza'
print(l)
s='python'
s[4]='a'
print(s)
l=[1,2]
l1=[2,1]
print(l==l1)
l=[1,2,3,8,6,'ali']
for i in l:
    print(i,end='*')

l=[100,20,30,8,6,'ali']

for i in range(len(l)):
    print(l[i])'''


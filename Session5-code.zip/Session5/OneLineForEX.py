l=['$sara','ali$']
a=[i.strip('$') for i in l]
print(a)
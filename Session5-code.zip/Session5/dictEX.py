l=['x','y','a','x','x','a','x']
#d={'x':4,'a':2,'y':1}
d={}
for i in l:
    if i in d.keys():
        d[i]=d[i]+1
    else:
        d[i]=1
print(d)
    
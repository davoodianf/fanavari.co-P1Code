l=[100,20,30,8,6,9,80,30,150,120]
l1=['s','d']
'''j=l.pop()
print('j :',j)
print('l :',l)
l.reverse()
print(l[::-1])
#print(l)'''
l.extend(l1)
#l.append(l1)
print('l :',l)
print('l1 :',l1)
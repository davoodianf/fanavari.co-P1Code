s=['ali','reza']
#i=s.lstrip('*')
#i=s.rstrip('*')
#i=s.strip('*')
#i=s.replace('*','')
l='*'.join(s)
print(l)


a=(3,8)
b=('x','y')
#c=zip(a,b)
#print(tuple(c))

f,i,o=(600,800,'ali')
print('f:',f)
print('i',i)
print('o :',o)
'''for i in range(4):
    print(i)'''
d=[i for i in range(8)]
a=[i for i in range(4)]
#print(a)
b=[i*2 for i in range(4)]
[0,2,4,6]
print(b)
c=[i for i in range(0,7,2)]
print(c)